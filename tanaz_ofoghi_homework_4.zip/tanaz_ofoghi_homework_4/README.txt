Project: tanaz_ofoghi_homework_4
Database platform: Microsoft SQL Server
Main file: tanaz_ofoghi_homework_4.sql

How to run:
1. Open SQL Server Management Studio (SSMS) and connect to your SQL Server instance.
2. Open the file tanaz_ofoghi_homework_4.sql.
3. Execute the whole script.
4. The script creates database TanazOfoghiHomework4, creates and fills two tables, then runs INNER JOIN, LEFT JOIN, RIGHT JOIN, and FULL OUTER JOIN examples.

The detailed educational explanation is provided separately in the chat, not inside the SQL code.
